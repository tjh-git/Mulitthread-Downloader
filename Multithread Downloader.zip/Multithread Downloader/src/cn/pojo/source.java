package cn.pojo;

public class source {
	private String state;
	private String name;
	private Long size;
	private String time;
	//"״̬", "�ļ�����", "�ļ���С",
	public source(String state,String name,Long size,String time) {
		this.state = state;
		this.name = name;
		this.size = size;
		this.time = time;
	}
	// ���췽��
		public  source(String string) {
			String[] strings = string.split("-");
				this.state = strings[0];
				this.name = strings[1];
				this.size = Long.valueOf(strings[2]);
				this.time = strings[3];
		}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getSize() {
		return size;
	}
	public void setSize(Long size) {
		this.size = size;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	
	
}
