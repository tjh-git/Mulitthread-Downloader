package cn.pojo;

/**
 * 
 * �����û���
 * 
 * @author tjh
 *
 */
public class User {
	 String username;
	 String userpass;
	  int vip;
	public User() {

	}

	public User(String string) {
	String[] strings = string.split("=");
	this.username = strings[0];
	this.userpass = strings[1];
	this.vip = Integer.valueOf(strings[2]);
}
	//���췽��
	public  User(String name, String password,int vip) {
		this.username = name;
		this.userpass = password;
		this.vip = vip;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserpass() {
		return userpass;
	}

	//public String set
	public void setUserpass(String userpass) {
		this.userpass = userpass;
	}

	public int getVip() {
		return vip;
	}

	public void setVip(int vip) {
		this.vip = vip;
	}
	@Override
	public String toString() {
		return username + "=" + userpass + "=" + vip;
	}
	

}
