package cn.view;

import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import cn.pojo.User;
import cn.util.JDBC;
import others.ManagerDemo;

public class ManagerFrame extends JFrame {

	private JPanel contentPane;
	private JTextField managername;
	private JPasswordField managerpass;

	/**
	 * Launch the application.
	 */

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
		
			public void run() {
				try {
					ManagerFrame frame = new ManagerFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ManagerFrame() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(File.separator + "eclipse" + File.separator + "ͷ��.jpg"));

		setTitle(" \u7BA1\u7406\u5458\u767B\u5F55");
		// �û����ܵ��ڽ����С
		this.setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 376, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		// ���ô������к������ʾ������Ļ�����У���
		setLocationRelativeTo(null);
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel passLabel = new JLabel("\u5BC6\u7801");
		passLabel.setBounds(32, 130, 58, 15);
		contentPane.add(passLabel);

		JLabel nameLabel = new JLabel("\u7528\u6237\u540D");
		nameLabel.setBounds(32, 82, 58, 15);
		contentPane.add(nameLabel);

		managername = new JTextField();
		managername.setBounds(111, 79, 143, 21);
		contentPane.add(managername);
		managername.setColumns(10);

		managerpass = new JPasswordField();
		managerpass.setBounds(111, 130, 143, 21);
		contentPane.add(managerpass);

		JButton exitbutton = new JButton("\u53D6\u6D88");
		// ȡ���������ת
		exitbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 ManagerFrame.this.dispose();
			}
		});
		exitbutton.setBounds(182, 197, 72, 23);
		contentPane.add(exitbutton);

		JButton loginbutton = new JButton("\u767B\u5F55");

		loginbutton.addActionListener(new ActionListener() {
			// ����Ա��¼����
			public void actionPerformed(ActionEvent e) {
				// ����û���������
				String username = managername.getText().trim();
				String password = managerpass.getText().trim();
				if("admin".equals(username)&&"abc123".equals(password)) {
					JOptionPane.showMessageDialog(contentPane.getParent(), "�û�ע��ɹ����ص���¼����");
					new ManagerDemo().setVisible(true);
					ManagerFrame.this.dispose();
				}else {
					JOptionPane.showMessageDialog(contentPane.getParent(), "�˺Ż��������");
				}
				// ע��ɹ��������¼����
				// goLogin();

			}
		});
		loginbutton.setBounds(79, 197, 66, 23);
		contentPane.add(loginbutton);

	}


}
