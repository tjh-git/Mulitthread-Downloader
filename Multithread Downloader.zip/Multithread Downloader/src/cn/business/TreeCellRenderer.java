package cn.business;

import java.awt.Component;
import javax.swing.ImageIcon;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;

/**
 * �Զ�����������,������ÿ���ڵ����óɲ�ͬ��ͼ��
 *
 */
public class TreeCellRenderer extends DefaultTreeCellRenderer {
	public TreeCellRenderer() {
	}


	/**
	 * ��д����DefaultTreeCellRenderer�ķ���
	 */
	@Override
	public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selected, boolean expanded,
			boolean isLeaf, int row, boolean hasFocus) {
		// ѡ��
		if (selected) {
			setForeground(getTextSelectionColor());
		} else {
			setForeground(getTextNonSelectionColor());
		}
		// TreeNode
		DefaultMutableTreeNode treeNode = (DefaultMutableTreeNode) value;
		Object obj = treeNode.getUserObject();
		if (obj instanceof TreeNode) {
			TreeNode node = (TreeNode) obj;
			DefaultTreeCellRenderer tempCellRenderer = new DefaultTreeCellRenderer();
			tempCellRenderer.setLeafIcon(new ImageIcon(node.getImagePath()));
			return tempCellRenderer.getTreeCellRendererComponent(tree, node.toString(), selected, expanded, true, row,
					hasFocus);
		} else if (obj instanceof String) {
			String text = (String) obj;
			DefaultTreeCellRenderer tempCellRenderer = new DefaultTreeCellRenderer();
			tempCellRenderer.setOpenIcon(new ImageIcon("Image/open.jpg"));
			tempCellRenderer.setClosedIcon(new ImageIcon("Image/close.jpg"));
			return tempCellRenderer.getTreeCellRendererComponent(tree, text, selected, expanded, false, row, hasFocus);
		}
		return super.getTreeCellRendererComponent(tree, value, selected, expanded, isLeaf, row, hasFocus);
	}
}
