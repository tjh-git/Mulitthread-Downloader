package others;

import java.util.EventObject;

public class MyEvent extends EventObject {
	private Object obj;
	private int sName;

	public MyEvent(Object source, int sName2) {
		super(source);
		this.obj = source;
		this.sName = sName2;
	}

	public Object getObj() {
		return obj;
	}

	public int getsName() {
		return sName;
	}
}
