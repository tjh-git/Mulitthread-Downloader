package others;

/**
 * ���ǹ���Ա���������û���Ϣ���Ľ���
 * @author tjh
 */
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import cn.pojo.User;
import cn.util.JDBC;
//import cn.view.DownloaderUI;
import cn.util.MD5Util;

import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;

public class ManagerDemo extends JFrame {
	private final static int W = 530;
	private final static int H = 450;
	private final static int X = (Toolkit.getDefaultToolkit().getScreenSize().width - W) / 2;
	private final static int Y = (Toolkit.getDefaultToolkit().getScreenSize().height - H) / 2;
	private JTextField usernameTextField;
	private JTextField userpassTextField;
	private JTextField addrTextField;
	private JTextField gradeTextField;
	private JTable table;
	private JButton preButton;
	private JButton postButton;
	private static JLabel totalPageLabel;// ��ʾ�ܵ�ҳ��

	private JComboBox levelComboBox;
	private JRadioButton tRadioButton;
	private JRadioButton fRadioButton;
	private ButtonGroup group;

	// private final static String[] columnNames = new String[] { "ѧ��", "����", "����",
	// "�Ա�", "����", "�ɼ�", "סַ" };
	private final static String[] columnNames = new String[] { "�˺�", "����","VIP" };
	private static ArrayList<User> list = new ArrayList<User>();
	private static int curPage = 0;// ��ǰҳ��
	private static int totalPage = 0;// �ܵ�ҳ��
	private final static int Pagecount = 6;// ÿҳ������ʾ������
	private DefaultTableModel model;

	private static BufferedReader reader;
	private static BufferedWriter writer;
	// E:\eclipse\java�߼�Ӧ��\Multithread Downloader
	// E:\\eclipse\\java�߼�Ӧ��\\Multithread Downloader\\
	private static File file = new File("user.txt");
	private static JTextField nowPagetextField;
	static JLabel nowPageLabel;
	//��̬�����
	static {
		// ��ʼ������
		try {
			//System.out.println("��ʼ������");
			// System.out.println(file.getAbsolutePath());
			reader = new BufferedReader(new FileReader(file));
			String string = null;
			while ((string = reader.readLine()) != null) {
				list.add(new User(string));
			}
			reader.close();
			setTotalLabel();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public ManagerDemo() {
		setTitle("\u7528\u6237\u4FE1\u606F\u7BA1\u7406");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setResizable(false);
		setBounds(X, Y, W, H);
		getContentPane().setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(48, 48, 424, 187);
		model = new DefaultTableModel(getData(), columnNames) {
			// ����isCellEditable�����ѵ�Ԫ������Ϊ���ɸ�
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};

		table = new JTable();
		table.setModel(model);
		table.setRowHeight(27);
		// ֻ��ѡ��һ��
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		// �����ƶ���
		table.getTableHeader().setReorderingAllowed(false);
		// ������ѡ���¼�
		table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				if (table.getSelectedRow() != -1) {
					int index = table.getSelectedRow() + curPage * 6;
					usernameTextField.setText(list.get(index).getUsername());
					userpassTextField.setText((list.get(index).getUserpass()));
					if (list.get(index).getVip()==1) {
						tRadioButton.setSelected(true);
					} else {
						fRadioButton.setSelected(true);
					}
				}

			}
		});
		scrollPane.setViewportView(table);
		getContentPane().add(scrollPane);

		preButton = new JButton("\u4E0A\u4E00\u9875");
		preButton.setBounds(155, 10, 93, 23);
		preButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				prePage();
			}
		});
		getContentPane().add(preButton);

		postButton = new JButton("\u4E0B\u4E00\u9875");
		postButton.setBounds(258, 10, 93, 23);
		postButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				postPage();
			}
		});
		getContentPane().add(postButton);

		JLabel nameLabel = new JLabel("\u8D26\u53F7");
		nameLabel.setBounds(26, 283, 36, 15);
		getContentPane().add(nameLabel);

		usernameTextField = new JTextField();
		usernameTextField.setBounds(72, 280, 240, 21);
		getContentPane().add(usernameTextField);
		usernameTextField.setColumns(10);

		JLabel ageLabel = new JLabel("\u5BC6\u7801");
		ageLabel.setBounds(26, 308, 36, 15);
		getContentPane().add(ageLabel);

		userpassTextField = new JTextField();
		userpassTextField.setColumns(10);
		userpassTextField.setBounds(72, 311, 240, 21);
		getContentPane().add(userpassTextField);

		JLabel addrLabel = new JLabel("\u4F4F\u5740\uFF1A");
		addrLabel.setBounds(26, 303, 36, 15);
		// getContentPane().add(addrLabel);

		addrTextField = new JTextField();
		addrTextField.setColumns(10);
		addrTextField.setBounds(72, 298, 176, 21);
		// getContentPane().add(addrTextField);

		JLabel vipLabel = new JLabel("VIP:");
		vipLabel.setBounds(339, 295, 36, 15);
		getContentPane().add(vipLabel);

		group = new ButtonGroup();

		tRadioButton = new JRadioButton("��");
		tRadioButton.setBounds(382, 291, 44, 23);
		group.add(tRadioButton);
		getContentPane().add(tRadioButton);

		fRadioButton = new JRadioButton("��");
		fRadioButton.setSelected(true);
		fRadioButton.setBounds(428, 291, 44, 23);
		group.add(fRadioButton);
		 getContentPane().add(fRadioButton);

		levelComboBox = new JComboBox();
		levelComboBox
				.setModel(new DefaultComboBoxModel(new String[] { "\u521D\u7EA7", "\u4E2D\u7EA7", "\u9AD8\u7EA7" }));
		levelComboBox.setBounds(431, 266, 51, 23);
		// getContentPane().add(levelComboBox);

		JLabel levelLabel = new JLabel("\u529F\u529B\uFF1A");
		levelLabel.setBounds(398, 270, 36, 15);
		// getContentPane().add(levelLabel);

		JLabel gradelabel = new JLabel("\u6210\u7EE9\uFF1A");
		gradelabel.setBounds(258, 303, 36, 15);
		// getContentPane().add(gradelabel);

		gradeTextField = new JTextField();
		gradeTextField.setColumns(10);
		gradeTextField.setBounds(302, 298, 180, 21);
		// getContentPane().add(gradeTextField);

		JButton addButton = new JButton("\u6DFB\u52A0");
		addButton.setBounds(26, 356, 72, 23);
		addButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addUser();
			}
		});
		getContentPane().add(addButton);

		JButton delButton = new JButton("\u5220\u9664");
		delButton.setBounds(186, 356, 72, 23);
		delButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int index = table.getSelectedRow() + curPage * Pagecount;
				// �п���ûѡ��
				if (table.getSelectedRow() != -1) {
					list.remove(index);
					updateTable();

					int lastPage = list.size() % Pagecount == 0 ? list.size() / Pagecount : list.size() / Pagecount + 1;
					String s = new String("��" + lastPage + "ҳ");
					totalPageLabel.setText(s);
					System.out.println("list size: " + list.size());

				}
			}
		});
		getContentPane().add(delButton);

		JButton updButton = new JButton("\u4FEE\u6539");
		updButton.setBounds(279, 356, 72, 23);
		updButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int index = table.getSelectedRow() + curPage * Pagecount;
				if (table.getSelectedRow() != -1) {
					try {
						
						// ����û���������
						String username = usernameTextField.getText().trim();
						String password = userpassTextField.getText().trim();
						//int vip = 
						// �û�������
						// String usernameRegex = "\\w{1,10}";
						String usernameRegex = "^[a-zA-Z][a-zA-Z0-9]{5,17}$";
						// �������adminer1
						String passwordRegex = "^[a-zA-Z](?![0-9]+$)|(?![a-zA-Z]+$)|([a-zA-Z0-9]|[._#@]){7,17}$";

						// У��
						if (!username.matches(usernameRegex)) {
							JOptionPane.showMessageDialog(null, "�û���������������Ҫ����ĸ��ͷ��������ĸ������ϻ��ߴ���ĸ��λ��6-18λ��");
							usernameTextField.setText("");
							usernameTextField.requestFocus();
							return;
						}

						if (!password.matches(passwordRegex)) {
							JOptionPane.showMessageDialog(null, "���벻����������Ҫ����ĸ��ͷ��������ĸ������ϣ����������ţ�λ��8-18λ��");
							userpassTextField.setText("");
							userpassTextField.requestFocus();
							return;
						}
						// ���Ϲ��������
						list.get(index).setUsername(username);
						list.get(index).setUserpass(password);
						if (tRadioButton.isSelected()) {
							list.get(index).setVip(1);
						}
						if (fRadioButton.isSelected()) {
							list.get(index).setVip(0);
						}
						updateTable();
						table.setRowSelectionInterval(index - curPage * Pagecount, index - curPage * Pagecount);
					} catch (Exception e2) {
						JOptionPane.showMessageDialog(ManagerDemo.this, "���ָ�ʽ����", "����", JOptionPane.WARNING_MESSAGE);
					}
				}
			}
		});

		getContentPane().add(updButton);

		//�رհ�ť
		JButton exitButton = new JButton("\u4FDD\u5B58\u5E76\u9000\u51FA");
		exitButton.setBounds(362, 356, 110, 23);
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
//				try {
//					writer = new BufferedWriter(new FileWriter(file));
//					for (User stu : list) {
//						writer.write(stu.toString());
//						writer.newLine();
//					}
//					writer.close();
//				} catch (IOException e1) {
//					// TODO Auto-generated catch block
//					e1.printStackTrace();
//				}
				try {
					synchronizeDATA();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				ManagerDemo.this.dispose();
			}
		});
		getContentPane().add(exitButton);

		nowPagetextField = new JTextField();
		nowPagetextField.setBounds(350, 245, 66, 21);
		getContentPane().add(nowPagetextField);
		nowPagetextField.setColumns(10);

		JButton goButton = new JButton("go");
		goButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int nowPage = Integer.valueOf((nowPagetextField.getText()));
				// ֻҪ��Ҫ����ҳ��С�ڵ������ҳ��
				if (nowPage <= (getLastPage()) && nowPage != 0) {
					curPage = nowPage - 1;
					updateTable();
				} else {
					JOptionPane.showMessageDialog(ManagerDemo.this, "ҳ��Ϊ���ҳ���������", "����", JOptionPane.WARNING_MESSAGE);
				}
				nowPagetextField.setText("");
			}
		});
		goButton.setBounds(423, 245, 48, 23);
		getContentPane().add(goButton);

		int lastPage = list.size() % Pagecount == 0 ? list.size() / Pagecount : list.size() / Pagecount + 1;
		String s = new String("��" + lastPage + "ҳ");
		totalPageLabel = new JLabel(s);
		totalPageLabel.setBounds(234, 245, 58, 15);
		getContentPane().add(totalPageLabel);

		nowPageLabel = new JLabel("��1ҳ");
		nowPageLabel.setBounds(48, 245, 58, 15);
		getContentPane().add(nowPageLabel);
		
		JButton searchButton = new JButton("\u67E5\u627E");
		searchButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//��������
			}
		});
		searchButton.setBounds(108, 356, 72, 23);
		getContentPane().add(searchButton);
		// int a = list.size()/curPage;
		// System.out.println(a);
	}

	private void updateTable() {
		model.setDataVector(getData(), columnNames);
		// nowPagetextField.setText(Integer.toString(curPage+1));
		nowPageLabel.setText("��" + String.valueOf(curPage + 1) + "ҳ");
		setTotalLabel();
	}

	private void prePage() {
		if (curPage > 0) {
			curPage--;
			updateTable();
		}
	}

	private void postPage() {
		int lastPage = list.size() % Pagecount == 0 ? list.size() / Pagecount - 1 : list.size() / Pagecount;
		if (curPage < lastPage) {
			curPage++;
			updateTable();
		}
	}

	// �����û�
	private void addUser() {

		// ����û���������
		String username = usernameTextField.getText().trim();
		String password = userpassTextField.getText().trim();

		// �û�������
		// String usernameRegex = "\\w{1,10}";
		String usernameRegex = "^[a-zA-Z][a-zA-Z0-9]{5,17}$";
		// �������adminer1
		String passwordRegex = "^[a-zA-Z](?![0-9]+$)|(?![a-zA-Z]+$)|([a-zA-Z0-9]|[._#@]){7,17}$";

		// У��
		if (!username.matches(usernameRegex)) {
			JOptionPane.showMessageDialog(null, "�û���������������Ҫ����ĸ��ͷ��������ĸ������ϻ��ߴ���ĸ��λ��6-18λ��");
			usernameTextField.setText("");
			usernameTextField.requestFocus();
			return;
		}

		if (!password.matches(passwordRegex)) {
			JOptionPane.showMessageDialog(null, "���벻����������Ҫ����ĸ��ͷ��������ĸ������ϣ����������ţ�λ��8-18λ��");
			userpassTextField.setText("");
			userpassTextField.requestFocus();
			return;
		}
		// System.out.println("list size: "+ list.size());
		User user = new User(username, password,0);
		if (isSameName(user)) {
			JOptionPane.showMessageDialog(null, "���˺��Ѵ��ڣ����������룡");
		} else {
			list.add(user);
			updateTable();

			int lastPage = list.size() % Pagecount == 0 ? list.size() / Pagecount : list.size() / Pagecount + 1;
			String s = new String("��" + lastPage + "ҳ");
			totalPageLabel.setText(s);
			// System.out.println("list size: "+ list.size());

			JOptionPane.showMessageDialog(null, "���ӳɹ���");
		}
		// synchronizeDB();
	}

	// �õ����ݣ�����һ���������ݵĶ�ά����
	private Object[][] getData() {
		int len = Math.min(list.size(), curPage * Pagecount + Pagecount);
		Object[][] objects = new Object[len - curPage * Pagecount][Pagecount];
		for (int i = curPage * Pagecount; i < len; i++) {
			User user = list.get(i);
			objects[i - curPage * Pagecount][0] = user.getUsername();
			objects[i - curPage * Pagecount][1] = user.getUserpass();
			if(user.getVip()==1)
				objects[i - curPage * Pagecount][2] = "��";
			else
				objects[i - curPage * Pagecount][2] = "��";
		}
		return objects;
	}

	/*
	 * �ж��ı��ļ��Ƿ�����ͬ���û���
	 * 
	 * @return true ����ͬ
	 * 
	 * @return false ��������ͬ������
	 */
	public static boolean isSameName(User user) {
		boolean flag = false;
		for (int i = 0; i < list.size(); i++) {
			if (user.getUsername().equals(list.get(i).getUsername())) {
				flag = true;
				return flag;
			}
		}
		return flag;
	}

	// �Ȱ�list���ݱ��浽TXT�ļ����ٰ�����ת�ɼ��ܸ�ʽ���浽���ݿ���
	public void synchronizeDATA() throws SQLException {// ͬ������
		//ͬ��TXT�ļ�����
		try {
			writer = new BufferedWriter(new FileWriter(file));
			for (User user : list) {
				writer.write(user.toString());
				writer.newLine();
			}
			writer.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		/*
		 * ͬ�����ݿ����ݣ����¼ӵ��û���Ϣ���ӵ����ݿ���
		 */
		//���ݿ������
		JDBC.Connection();
		
		//��Ϊ����Ա�����޸��˴������ݣ����һȥ�������޸ģ�̫�˷�ʱ���ˣ�����ֱ��ɾ��������Ϣ��Ȼ���ٰ�list����Ϣ���ӵ����ݿ�ͺ���
		JDBC.delAllUser();
		JDBC.delVip();
		
		for(User user : list) {
			//String name = user.getUsername();
			//String pass = user.getUserpass();
			
			//list�е��û���Ϣ���˺ţ��������ݿ���
			if(!JDBC.isExistUsername(user)) {
				//������ת��MD5��
				String md5Name = MD5Util.getMD5Code(user.getUsername());
				//System.out.println("�����˺ţ�"+user.getUsername());
				//String md5Pass = MD5Util.getMD5Code(user.getUserpass());
				JDBC.saveUserInfo(user.getUsername(), user.getUserpass());
			}
			
			//����VIP����Ϣ
			JDBC.saveUserVipInfo(user);
		}
		
		
		//���ݿ�Ĺر�
		JDBC.closeAll();
	}

	/**
	 * ���ܵ�ҳ��
	 */
	public static void setTotalLabel() {
		totalPage = list.size() % Pagecount == 0 ? list.size() / Pagecount : list.size() / Pagecount + 1;
		// label.setText("��"+totalPage+"ҳ");

	}

	// ���ر������һҳҳ��
	public int getLastPage() {
		int lastPage = list.size() % Pagecount == 0 ? list.size() / Pagecount : list.size() / Pagecount + 1;
		return lastPage;
	}

	public static void main(String[] args) {
		new ManagerDemo().setVisible(true);
	}
}