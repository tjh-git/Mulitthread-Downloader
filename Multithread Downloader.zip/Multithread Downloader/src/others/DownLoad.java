package others;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Label;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import cn.pojo.source;
import cn.view.UpdateListener;

public class DownLoad extends JFrame {//BaseEvent
	// ����
	//private Vector list = new Vector();
	// �����ļ�ʱ�������̵߳ĸ�����Ĭ��Ϊ1��
	// �����ļ������ص�ַ
	static String path = "";
	// �ϴ����ش�С
	// static int preLength = 0;
	// public static boolean state = false;
	public static long total = 0;
	// ������Ϣ
	// DownLoadInfo infos;
	// ���������ļ�Ĭ�ϵ�ַ:D:\\MyDownLoad����ʱû�õ�
	// static String defualtPath = "D:" + File.separator + "MyDownLoad";

	// �����ܵ�ַ=����Ŀ¼+�����ļ���
	// static String save = "";// ��·��
	public static JTextField saveFileNameText;// �����ļ���

	// private static JComboBox ThreadCount_1;// �����Ľ�������
	private static JLabel resavelable;
	static DownLoad frame;
	private JPanel contentPane;
	// protected Shell shell;// ����

	// private Text txt;

	private static JTextField downloadPathText;// ���ص�ַ

	private static JComboBox ThreadCount;// �����Ľ�������
	// private Combo combo;
	// �����ֽ�
	private static long sum;
	// ������
	// private ProgressBar progressBar;
	private static File downLoadFile;
	// ����
	private static JTextField download;
	// �����ַ
	private static JTextField savePathText;// ����·��
	// private Text text;
	private Map<String, List<ThreadInfo>> threadInfos = new HashMap<String, List<ThreadInfo>>();
	// private Label label_2;
	private static String key;
	static DownLoadUtils dlu;
	
	ArrayList<source> list = new ArrayList<source>();
	private static String state ="unfinish";
	String time;
	/**
	 * Create the frame.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new DownLoad();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

	}

	/**
	 * Create contents of the window.
	 */

	public DownLoad() {
		setTitle("\u65B0\u5EFA\u4E0B\u8F7D\u4EFB\u52A1");
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		int width = 500;
		int height = 350;
		 //���ô������
		setBounds((d.width - width) / 2, (d.height - height) / 2, width, height);
		 //���ô����С���ɸ�
		this.setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		JPanel main = new JPanel();
		contentPane.add(main, BorderLayout.CENTER);
		main.setLayout(null);

		// ����
		JLabel downlaodPathLabel = new JLabel("\u4E0B\u8F7D\u5730\u5740\uFF1A");
		downlaodPathLabel.setFont(new Font("����", Font.PLAIN, 16));
		downlaodPathLabel.setBounds(36, 37, 82, 22);
		main.add(downlaodPathLabel);

		downloadPathText = new JTextField();
		downloadPathText.setBounds(128, 33, 301, 34);
		main.add(downloadPathText);
		downloadPathText.setColumns(30);

		// ����
		resavelable = new JLabel("\u53E6\u5B58\u6587\u4EF6\u540D:");
		resavelable.setFont(new Font("����", Font.PLAIN, 16));
		resavelable.setBounds(36, 136, 100, 22);
		//main.add(resavelable);

		saveFileNameText = new JTextField();
		saveFileNameText.setColumns(30);
		saveFileNameText.setBounds(130, 131, 161, 34);
		//main.add(saveFileNameText);

		//���ؿ�ʼ
		//dl();
		// ȷ����ť
		JButton commit = new JButton("\u786E\u5B9A");
		commit.setFont(new Font("����", Font.PLAIN, 16));
		commit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//frame.dispose();
				sum = 0; // ÿ�ε����ʼʱ��Ҫ��sum����ֵΪ0
				// savePathText.setText(getsaveName());
				
				String urlString = downloadPathText.getText().trim();// ���ص�ַ
				int threadSize = Integer.parseInt((String) ThreadCount.getSelectedItem());// �߳���
				String savePath = savePathText.getText();// �����ַ
				System.out.println("URLString :" + urlString);
				System.out.println("threadSize��" + threadSize);
				System.out.println("savePath��" + savePath);// Ŀ¼
				
				try {
					dlu = new DownLoadUtils(threadSize, urlString, savePath);
					downLoadFile = dlu.getDownLoadFile();
					key = threadSize + "_" + urlString + "_" + downLoadFile.getAbsolutePath();
					// ���ý�����progressbar���ܳ���
					// progressBar.setMaximum((int) downLoadFile.length());
					long allThreadDownLoadedSize = dlu.getAllThreadDownLoadedSize(key);

					// label_2.setText("�ܳ���:" + (int) downLoadFile.length() + "/�����صĳ���" +
					// allThreadDownLoadedSize);
					System.out.println("�ܳ���: " + (int) downLoadFile.length() + "�����صĳ���: " + allThreadDownLoadedSize);
					 
					String name = urlString.substring(urlString.lastIndexOf("/") + 1, urlString.length());
					//�Ѽ�¼д���ļ�
					time = getNowTime();
					add(state,name,downLoadFile.length(),time);
					if ((int) downLoadFile.length() == allThreadDownLoadedSize) {
						// System.exit(0);
					}
					sum += allThreadDownLoadedSize;

					dlu.downLoad(downLoadFile, urlString, threadSize, new OnSizeChangeListener() {
						public void onSizeChange(long downLoadSize) {
							sum += downLoadSize;
//							Display.getDefault().asyncExec(new Runnable() {
//								@Override
//								public void run() {
//									//progressBar.setSelection((int) sum);
//									label_2.setText("�ܳ���:" + (int) downLoadFile.length() + "/�����صĳ���" + sum);
//								}
//							});��ʾ
							// label_2.setText("�ܳ���:" + (int) downLoadFile.length() + "/�����صĳ���" + sum);
							System.out.println("�ܳ���:" + (int) downLoadFile.length() + "/�����صĳ���" + sum);
							total =sum;
							if (sum >= downLoadFile.length()) {
								dlu.stop();
//								Display.getDefault().asyncExec(new Runnable() {
//									@Override
//									public void run() {
//										MessageBox mb = new MessageBox(shell, SWT.NO);
//										mb.setText("�������");
//										mb.setMessage("OK");
//										mb.open();
//									}
//								});
								System.out.println("������ɣ�");
								state = "finish";
								try {
									time = getNowTime();
									add(state,name,downLoadFile.length(),time);
								} catch (IOException e) {
									e.printStackTrace();
								}
								
								//ɾ����ʱ�ļ�
								String userHome = System.getProperty("user.home");
								File file1 = new File(userHome+File.separator+"data.tmp");
								//System.out.println(file1);
								file1.delete();
								System.out.println("��ʱ�ļ�ɾ���ɹ���");
								
							}

						}

					});
					total = sum;
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});

		commit.setBounds(128, 255, 82, 23);
		main.add(commit);

		// ȡ��
		JButton Chanel = new JButton("\u53D6\u6D88");
		Chanel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (dlu != null) {
					dlu.stop();
				}
			}
		});
		Chanel.setFont(new Font("����", Font.PLAIN, 16));
		Chanel.setBounds(259, 255, 82, 23);
		main.add(Chanel);

		// �����ǩ
		JLabel savelable = new JLabel("\u4FDD\u5B58\u76EE\u5F55\uFF1A");
		savelable.setFont(new Font("����", Font.PLAIN, 16));
		savelable.setBounds(36, 91, 82, 22);
		main.add(savelable);

		// ��ʼ�������ַ
		savePathText = new JTextField();
		savePathText.setColumns(10);
		savePathText.setBounds(128, 87, 301, 34);
		main.add(savePathText);

		// �߳�����ǩ
		JLabel countlabel = new JLabel("\u7EBF\u7A0B\u6570\uFF1A");
		countlabel.setFont(new Font("����", Font.PLAIN, 16));
		countlabel.setBounds(36, 185, 71, 22);
		main.add(countlabel);

		// �߳��������б�
		ThreadCount = new JComboBox();
		ThreadCount.setBounds(128, 186, 51, 23);
		ThreadCount.setModel(new DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "6", "8", "9", "10" }));
		main.add(ThreadCount);

		// ����Ĭ��Ŀ¼Ϊ�����û����ļ���
		String userHome = System.getProperty("user.home");// �û�����Ŀ¼
		// savePathText.setText(userHome);
		savePathText.setText("D:\\down");
		// �߳���������
		JLabel fontLable = new JLabel(
				"\uFF08\u5F00\u542F\u591A\u7EBF\u7A0B\u540E\uFF0C\u4E0B\u8F7D\u901F\u5EA6\u4F1A\u53D8\u5FEB\uFF09");
		fontLable.setFont(new Font("����", Font.PLAIN, 16));
		fontLable.setBounds(189, 185, 271, 22);
		main.add(fontLable);

		// ����Ϊ��ť
		JButton button = new JButton("\u53E6\u5B58\u4E3A");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// ͬ��·��,������Ϊ��ť�ķ���ֵ������Ŀ¼
				savePathText.setText(getSaveFilePath());
			}
		});
		button.setBounds(336, 137, 97, 23);
		main.add(button);

	}
//	//�����յı����ַ
//	public String getsaveName() {
//		String idFolder = "";
//		// ��ַ=Ĭ�ϵ�ַ+�˺����ļ���+�ļ��� 
//		String path = savePathText.getText() + idFolder + File.separator + saveFileNameText.getText();// �����ַ
//		return path;
//	}

	// ��������Ϊ��ַ
	private String getSaveFilePath() {
		String userHome = System.getProperty("user.home");
		JFileChooser fileChooser = new JFileChooser(userHome);
		fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		int returnVal = fileChooser.showOpenDialog(fileChooser);
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			String filePath = fileChooser.getSelectedFile().getAbsolutePath();// ���������ѡ����ļ��е�·��
			// System.out.println(filePath);
			// ͬ��·��
			savePathText.setText(filePath);
			return filePath;
		}
		return null;
	}

	public String getInfo() {
		return "����Ŀ¼" + savePathText.getText() + "���ؽ���" + sum + downloadPathText.getText()
				.substring(downloadPathText.getText().lastIndexOf("/") + 1, downloadPathText.getText().length());
	}
//	public static  My my = new My();
//	public static class My extends AbstractSubject {
//		
//		public My(){
//			
//		}
//		private int n;
//
//		public int getN() {
//			return n;
//		}
//
//		public void setN(int n) {
//			this.n = n;
//		}
//
//		/**
//		 * ���±���n��ֵ
//		 */
//		@Override
//		public void operation() {
//			notifyAllUpdateListener(sum);
////			for (int i = 0; i < 10; i++) {
////				// ���±�����ֵ
////				++n;
////				System.out.println("B�еı���n��ֵΪ��" + n);
////				notifyAllUpdateListener(n);
////				try {
////					Thread.sleep(5000);
////				} catch (InterruptedException e) {
////					e.printStackTrace();
////				}
////			}
//		}
//
//		@Override
//		public void addUpdateListener(UpdateListener updateListener) {
//			// TODO Auto-generated method stub
//			
//		}
//
//		@Override
//		public void delUpdateListener(UpdateListener updateListener) {
//			// TODO Auto-generated method stub
//			
//		}
//
//	}

	public Long getSumEvent() {
		// TODO Auto-generated method stub
		return sum;
	}
	
	
	
//	 public void move(Long long1) {
//	        this.sum = long1;
//	      
//
////	        if (x == 6) {
////	            //���Բ�ͬ���ʱ��Listener��ִ�����
////	            isMove = false;
////	        } else {
////	            isMove = true;
////	        }
//	        String msg = "���꣺(" + getX()   + ")";
//	        //������Ϣ
//	        notify(msg);
//	    }
//
//	    public Long getX() {
//	        return sum;
//	    }
	
	public void add(String state,String name,Long size,String time) throws IOException {
		File file = new File("D:\\down\\info.txt");
		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new FileWriter(file,true));
		} catch (FileNotFoundException e2) {
			e2.printStackTrace();
		}
		String s = state+"-"+name+"-"+size+"-"+time;
		writer.write(s+"\r\n");
		writer.close();
	}
	
	//��ȡ��ǰʱ��
	public String getNowTime() {
		Date date = new Date();
		SimpleDateFormat sdfl = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		return sdfl.format(date);
		//System.out.println(sdfl.format(date));
	}
	
	
}
