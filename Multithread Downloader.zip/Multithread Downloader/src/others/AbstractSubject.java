package others;

import java.util.Iterator;
import java.util.Vector;

import cn.view.UpdateListener;

public  class AbstractSubject implements Subject {
    private Vector<UpdateListener> vector = new Vector<UpdateListener>();
 
    /**
     * ���Ӹ��¼�����
     *
     * @param updateListener
     */
    public void addUpdateListener(UpdateListener updateListener) {
        vector.add(updateListener);
    }
 
    /**
     * �Ƴ����¼�����
     *
     * @param updateListener
     */
    public void delUpdateListener(UpdateListener updateListener) {
        vector.remove(updateListener);
    }
 
    /**
     * ֪ͨ���еĸ��¼�����
     *
     * @param sum
     */
    public void notifyAllUpdateListener(long sum) {
        Iterator<UpdateListener> iterator = vector.iterator();
        while (iterator.hasNext()) {
            UpdateListener listener = iterator.next();
            listener.update(sum);
        }
    }

	public void operation() {
		
	}


 
}