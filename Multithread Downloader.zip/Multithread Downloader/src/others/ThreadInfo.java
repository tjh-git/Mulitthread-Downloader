package others;
 
import java.io.Serializable;
 
public class ThreadInfo implements Serializable {
	private static final long serialVersionUID = -8664947024042932015L;
	private int threadId;
	private long downLoadSize;
 
	public int getThreadId() {
		return threadId;
	}
 
	public void setThreadId(int threadId) {
		this.threadId = threadId;
	}
 
	public long getDownLoadSize() {
		return downLoadSize;
	}
 
	public void setDownLoadSize(long downLoadSize) {
		this.downLoadSize = downLoadSize;
	}
 
	public ThreadInfo(int threadId, long downLoadSize) {
		super();
		this.threadId = threadId;
		this.downLoadSize = downLoadSize;
	}
 
	public ThreadInfo() {
		super();
	}
 
	@Override
	public String toString() {
		return threadId + "\t" + downLoadSize;
	}
 
}